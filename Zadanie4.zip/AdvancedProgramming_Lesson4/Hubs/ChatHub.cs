using AdvancedProgramming_Lesson4.Data;
using AdvancedProgramming_Lesson4.Models;
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace AdvancedProgramming_Lesson4.Hubs
{
    public class ChatHub : Hub
    {
        private readonly ApplicationDbContext _context;

        public ChatHub(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task Sendmessage(string user, string message)
        {
            await Clients.All.SendAsync("Receivemessage", user, message);
            var authenticated = Context.User.Identity.IsAuthenticated;

            if (authenticated)
            {
                System.Diagnostics.Debug.WriteLine("tak", Context.User.Identity.Name);
                messages msg = new messages();
                msg.username = Context.User.Identity.Name;
                msg.message = message;
                msg.Authenticated = authenticated;
                _context.messages.Add(msg);
                _context.SaveChanges();
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("nie");
                messages msg = new messages();
                msg.username = user;
                msg.message = message;
                msg.Authenticated = authenticated;
                _context.messages.Add(msg);
                _context.SaveChanges();
            }
        }
    }
}
