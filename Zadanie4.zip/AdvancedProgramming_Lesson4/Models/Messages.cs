﻿using System.ComponentModel.DataAnnotations;

namespace AdvancedProgramming_Lesson4.Models
{
    public class messages
    {
        public int Id { get; set; }
        [Display(Name = "Użytkownik")]
        public string username { get; set; }
        [Display(Name = "Wiaddomości")]
        public string message { get; set; }
        public bool Authenticated { get; set; }
         
    }
}
