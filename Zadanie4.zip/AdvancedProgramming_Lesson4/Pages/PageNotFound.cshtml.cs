using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AdvancedProgramming_Lesson4.Pages
{
    public class PageNotFoundModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
